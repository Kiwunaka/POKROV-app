from pathlib import Path
import datetime,hashlib,json,subprocess
out=Path(__file__).parent
def read(name):return json.loads((out/(name+'.json')).read_text(encoding='utf-8-sig'))
installed=read('installed');assert installed['preferences_unchanged'] and installed['uid_preserved'] and installed['shared_preferences_files']==6
assert installed['after_apk_sha256']=='7ffacdfae3273d0b03d07a4d2157100606ad49fa8d81e466f3df437ca66184c0' and installed['source_client']=='8067520c7b9230ab0c66823fae9ae78791f1a838'
before=read('precrash-observability');dead=read('crashed-observability');after=read('relaunched-observability');final=read('final-observability')
assert before['app_pid']==read('crash')['old_app_pid'] and dead['app_pid'] is None and after['app_pid']!=before['app_pid']
assert before['marker']==dead['marker'] and before['marker']['state']=='active' and after['marker']['run_id_sha256']!=before['marker']['run_id_sha256']
assert before['current_source_events']==dead['current_source_events']
ids={x['event_id_sha256'] for x in before['current_source_events']};assert len(ids)==30 and ids<={x['event_id_sha256'] for x in after['current_source_events']}
detected=[x for x in after['current_source_events'] if x['run_id_sha256']==after['marker']['run_id_sha256'] and x['name']=='app.previous_exit.detected'];assert len(detected)==1 and detected[0]['error_code']=='APP-BOOT-006'
assert all(x['build_number']=='4053' and x['source_client']==installed['source_client'] for x in final['current_source_events'])
for baseline_name,current_name in [('baseline','after-crash'),('baseline','disconnected'),('rootless-before','rootless-final')]:
 a=read(baseline_name);b=read(current_name);assert not b['tun_interfaces'] and a['ipv6_semantic_sha256']==b['ipv6_semantic_sha256']
 assert all(v==b['network_state_hashes'][k] for k,v in a['network_state_hashes'].items() if k!='ipv6_routes')
for name in ['disconnected','rootless-final']:assert not read(name)['vpn_service_record_present']
for name in ['connected','reconnected','rootless-connected']:assert read(name)['tun_interfaces'] and read(name)['vpn_service_record_present']
names=['connected-http','reconnected-http','disconnected-http','rootless-connected-http','rootless-final-http']
for name in names:
 p=read(name);assert p['status']=='PASS' and len(p['requests'])==3 and all(x['status']==204 and x['marker_valid'] for x in p['requests'])
assert read('rootless-guest')['su_exit']==127 and read('root-restored')['root_mode'] is False
config=json.loads(Path('E:/LDPlayer/LDPlayer14/vms/config/leidian3.config').read_bytes());assert config['basicSettings.rootMode'] is False
for report in [read('restoration'),read('rootless/restoration')]:assert report['all_instances_stopped'] and report['other_disk_sizes_unchanged'] and report['floor_sampled_pass'] and report['growth_budget_pass'] and 'guard_quit' not in report
assert all(x.split(',')[4]=='0' for x in subprocess.check_output(['E:/LDPlayer/LDPlayer14/ldconsole.exe','list2'],text=True).splitlines())
host=read('host-network-installed-after');assert host['routes_match_before'] and host['dns_match_before']
case=read('owned-case-readback');assert case['case_number']==65 and case['bundle']['status']=='validated' and case['bundle']['diagnostic_profile']=='summary' and case['bundle']['expected_size_bytes']==case['bundle']['received_size_bytes']==2398
result={'status':'PASS_BOUNDED_806_X64_UPDATE_CRASH_AND_ROOTLESS_RECOVERY','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_client':installed['source_client'],'source_core':installed['source_core'],'apk_sha256':installed['after_apk_sha256'],'same_signer_update':True,'uid_and_six_preferences_preserved':True,'native_crash_old_pid':before['app_pid'],'relaunch_pid':after['app_pid'],'retained_precrash_events':len(ids),'final_source_events':len(final['current_source_events']),'previous_exit_code':'APP-BOOT-006','previous_exit_kind':'unclean','marker_bytes_preserved':True,'rooted_crash_fixture':True,'rootless_su_exit':127,'https_checks_passed':15,'https_groups':names,'support_case':65,'support_bundle_profile':'summary','support_bundle_status':'validated','support_bundle_ciphertext_bytes':2398,'support_bundle_ciphertext_sha256':case['bundle']['expected_sha256'],'crash_handler_execution':'NOT_PROVEN','crash_bundle_delivery':'NOT_PROVEN','admin_plaintext_access_retested':False,'freeze_retested':False,'physical_arm64':'NOT_PERFORMED','windows806':'NOT_PERFORMED','network_recovery':'IPv4/DNS exact per boot; IPv6 matches each boot baseline after only observed expiry countdown normalization','ipv6_cross_boot_equality_claimed':False,'host_routes_dns_unchanged':True,'all_local_emulators_stopped':True,'root_setting_restored':True,'full_release_gates':'OPEN'}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
