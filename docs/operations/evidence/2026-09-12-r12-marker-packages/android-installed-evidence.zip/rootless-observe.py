from pathlib import Path
import datetime,hashlib,json,subprocess
import observe,ui
out=Path(__file__).parent
assert observe.installed()=='7ffacdfae3273d0b03d07a4d2157100606ad49fa8d81e466f3df437ca66184c0'
p=subprocess.run([ui.adb,'-s',ui.serial,'shell','su','-c','id'],capture_output=True,timeout=10)
assert p.returncode==127 and b'uid=0(root)' not in p.stdout
config=json.loads(Path('E:/LDPlayer/LDPlayer14/vms/config/leidian3.config').read_bytes());assert config['basicSettings.rootMode'] is False
r={'status':'PASS_ROOTLESS_GUEST_AND_EXACT_806','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'installed_apk_sha256':observe.installed(),'root_mode_config':False,'su_exit':p.returncode,'su_stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'su_stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'sdk':ui.run('shell','getprop','ro.build.version.sdk').decode().strip(),'boot_id_sha256':hashlib.sha256(ui.run('shell','cat','/proc/sys/kernel/random/boot_id').strip()).hexdigest()}
(out/'rootless-guest.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
