from pathlib import Path
r=Path(__file__).parent
s=Path('C:/r12-6b-android-support-20260912/read-case.py').read_text(encoding='utf-8').replace('SupportTicket,58','SupportTicket,65').replace('ticket_id==58','ticket_id==65').replace("'case_number':58","'case_number':65").replace('dt.datetime(2026,9,12,4,23)','dt.datetime(2026,9,12,13,0)')
s=s.replace('assert u.is_app_user and u.account_id==t.account_id',"assert u.is_app_user and u.account_id==t.account_id and hashlib.sha256(str(u.app_install_id).encode()).hexdigest()=='a8e19d7739f511e191aba5d7bdef9162fc2f91c0709a5d34f516313a7ed8f557'")
(r/'read-case.py').write_text(s,encoding='utf-8')
